from src.retirement import Retirement

# Team 16
# retirement tests start here
def test_retirement_age():
    calc = Retirement.retirement_age_calc(1942) == 1942
    assert Retirement.retirement_age_year == 65
    assert Retirement.retirement_age_month == 10

def test_retirement_age2():
    return_age = Retirement.retirement_age_calc(1955)
    assert Retirement.retirement_age_year == 66
    assert Retirement.reirement_age_moth == 2

def test_retirement_age3():
    return_age = Retirement.retirement_age_calc(1958)
    assert Retirement.retirement_age_year == 66
    assert Retirement.reirement_age_moth == 6

def test_retirement_age4():
    return_age = Retirement.retirement_age_calc(1962)
    assert Retirement.retirement_age_year == 67

def test_retirement_date_calc():
    correct_date = Retirement.retirement_date_calc(12)
    assert correct_date == 0

def test_convert_month_to_string():
    string_test = Retirement.convert_month_to_string(4)
    assert string_test == "April"

def test_date_validation():
    validation = Retirement.date_validation(1899, "year")
    assert validation == False

