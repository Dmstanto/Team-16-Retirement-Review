from src.RetirementCalculator import RetirementCalculator

# Team 16

def test_get_user_choice():
    RetirementCalculator.input = lambda: 'enter'
    output = RetirementCalculator.get_user_choice()
    assert output == 'enter'

def test_validate_user_choice(user_choice):
    validation = RetirementCalculator.user_choice("test")
    assert validation == False
